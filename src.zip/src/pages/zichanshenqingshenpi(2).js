import React from 'react';

const ApplicationForm = () => {
  // Watermark SVG generated as a data URI for the repeating background
  const watermarkUrl = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='350' height='250'><text x='50%' y='50%' transform='rotate(-20 175 125)' fill='rgba(0, 0, 0, 0.03)' font-size='20' font-family='sans-serif' text-anchor='middle'>何文206984</text></svg>";

  return (
    <div className="min-h-screen bg-[#f5f5f5] p-4 md:p-8 flex justify-center text-[14px] text-[rgba(0,0,0,0.88)] font-[system-ui,-apple-system,'Segoe_UI',Roboto,'Helvetica_Neue',Arial,sans-serif]">
      
      {/* Main Form Container - Antd Card Style */}
      <div 
        className="w-full max-w-[1200px] bg-white rounded-lg shadow-[0_1px_2px_0_rgba(0,0,0,0.03),0_1px_6px_-1px_rgba(0,0,0,0.02),0_2px_4px_0_rgba(0,0,0,0.02)] border border-[#f0f0f0] pb-8 relative overflow-hidden"
        style={{ backgroundImage: `url("${watermarkUrl}")`, backgroundRepeat: 'repeat' }}
      >
        
        {/* Top Header - Antd PageHeader simulation */}
        <div className="border-b border-[#f0f0f0] px-6 py-4 flex justify-between items-center bg-white relative z-10">
          <div className="flex items-center">
            <div className="w-1 h-4 bg-[#1677ff] mr-3 rounded-sm"></div>
            <h1 className="text-lg font-semibold text-[rgba(0,0,0,0.88)]">统一申请单</h1>
          </div>
          <div className="text-[rgba(0,0,0,0.45)] text-sm">
            申请单号: <span className="text-[rgba(0,0,0,0.88)] font-medium">CA-2026071500001</span>
          </div>
        </div>

        <div className="px-6 md:px-8 space-y-8 pt-6">
          
          {/* 申请人信息 (Applicant Information) */}
          <section>
            <div className="flex items-center mb-4">
              <h2 className="text-base font-semibold text-[rgba(0,0,0,0.88)]">申请人信息</h2>
            </div>
            
            {/* Updated 3-column grid layout with new fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-5 gap-x-8 pl-1">
              <div className="flex items-start">
                <span className="w-20 text-[rgba(0,0,0,0.65)] shrink-0">申请人:</span>
                <span className="flex-1 text-[rgba(0,0,0,0.88)]">200620-王英</span>
              </div>
              <div className="flex items-start">
                <span className="w-20 text-[rgba(0,0,0,0.65)] shrink-0">申请日期:</span>
                <span className="flex-1 text-[rgba(0,0,0,0.88)]">2026-07-15</span>
              </div>
              <div className="flex items-start">
                <span className="w-20 text-[rgba(0,0,0,0.65)] shrink-0">电话:</span>
                <span className="flex-1 text-[rgba(0,0,0,0.88)]">010-00000001</span>
              </div>
              <div className="flex items-start">
                <span className="w-20 text-[rgba(0,0,0,0.65)] shrink-0">邮箱:</span>
                <span className="flex-1 text-[rgba(0,0,0,0.88)] break-all">yingwang200620@sohu-lab.com</span>
              </div>
              <div className="flex items-start">
                <span className="w-20 text-[rgba(0,0,0,0.65)] shrink-0">公司:</span>
                <span className="flex-1 text-[rgba(0,0,0,0.88)]">搜狐集团</span>
              </div>
              <div className="flex items-start">
                <span className="w-20 text-[rgba(0,0,0,0.65)] shrink-0">办公区:</span>
                <span className="flex-1 text-[rgba(0,0,0,0.88)]">北京总部</span>
              </div>
              <div className="flex items-start col-span-1 md:col-span-2 lg:col-span-3">
                <span className="w-20 text-[rgba(0,0,0,0.65)] shrink-0">部门:</span>
                <span className="flex-1 text-[rgba(0,0,0,0.88)]">集团总部.员工服务中心.资产部</span>
              </div>
            </div>
          </section>

          {/* 申请物资信息 (Material Request Information) */}
          <section>
            <div className="flex items-center mb-4">
              <h2 className="text-base font-semibold text-[rgba(0,0,0,0.88)]">申请物资信息</h2>
            </div>
            
            {/* Antd Styled Table (Bordered) */}
            <div className="overflow-x-auto border border-[#f0f0f0] rounded-md relative z-10 bg-white/50 backdrop-blur-sm">
              <table className="w-full text-left border-collapse min-w-[800px]">
                <thead>
                  <tr className="bg-[#fafafa] border-b border-[#f0f0f0]">
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[25%] font-semibold text-[rgba(0,0,0,0.88)]">物资说明</th>
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[15%] font-semibold text-[rgba(0,0,0,0.88)]">配置</th>
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[20%] font-semibold text-[rgba(0,0,0,0.88)]">详细说明</th>
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[15%] font-semibold text-[rgba(0,0,0,0.88)]">申请原因</th>
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[10%] font-semibold text-[rgba(0,0,0,0.88)]">申请用途</th>
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[10%] font-semibold text-[rgba(0,0,0,0.88)]">是否超标</th>
                    <th className="p-3.5 w-[5%] font-semibold text-[rgba(0,0,0,0.88)]">数量</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-[#f0f0f0] hover:bg-[#fafafa] transition-colors bg-white">
                    <td className="p-3.5 border-r border-[#f0f0f0]">笔记本-标准笔记本.缺省.标配笔记本</td>
                    <td className="p-3.5 border-r border-[#f0f0f0]">无</td>
                    <td className="p-3.5 border-r border-[#f0f0f0] text-center">1</td>
                    <td className="p-3.5 border-r border-[#f0f0f0] text-center">1</td>
                    <td className="p-3.5 border-r border-[#f0f0f0] text-center">专业用途</td>
                    <td className="p-3.5 border-r border-[#f0f0f0] text-center">是</td>
                    <td className="p-3.5 text-center">1</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* 审批信息 (Approval Information) */}
          <section>
            <div className="flex items-center mb-4">
              <h2 className="text-base font-semibold text-[rgba(0,0,0,0.88)]">审批信息</h2>
            </div>
            
            <div className="overflow-x-auto border border-[#f0f0f0] rounded-md relative z-10 bg-white/50 backdrop-blur-sm">
              <table className="w-full text-left border-collapse min-w-[800px]">
                <thead>
                  <tr className="bg-[#fafafa] border-b border-[#f0f0f0]">
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[15%] font-semibold text-[rgba(0,0,0,0.88)]">审批环节</th>
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[20%] font-semibold text-[rgba(0,0,0,0.88)]">申请人/审批人</th>
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[15%] font-semibold text-[rgba(0,0,0,0.88)]">代理人</th>
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[15%] font-semibold text-[rgba(0,0,0,0.88)]">审批状态</th>
                    <th className="p-3.5 border-r border-[#f0f0f0] w-[15%] font-semibold text-[rgba(0,0,0,0.88)]">审批时间</th>
                    <th className="p-3.5 w-[20%] font-semibold text-[rgba(0,0,0,0.88)]">审批意见</th>
                  </tr>
                </thead>
                <tbody>
                  {/* Antd active/selected row state representation */}
                  <tr className="border-b border-[#f0f0f0] bg-[#e6f4ff] hover:bg-[#e6f4ff] transition-colors">
                    <td className="p-3.5 border-r border-[#f0f0f0]">开始</td>
                    <td className="p-3.5 border-r border-[#f0f0f0]">200620-王英</td>
                    <td className="p-3.5 border-r border-[#f0f0f0]"></td>
                    <td className="p-3.5 border-r border-[#f0f0f0]">已提交</td>
                    <td className="p-3.5 border-r border-[#f0f0f0]">2026-07-15</td>
                    <td className="p-3.5"></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* 审批意见 Input (Approval Comment) */}
          <section className="mt-8">
            <h3 className="text-[rgba(0,0,0,0.88)] font-semibold mb-3">审批意见</h3>
            <textarea 
              className="w-full border border-[#d9d9d9] hover:border-[#1677ff] focus:border-[#1677ff] focus:shadow-[0_0_0_2px_rgba(22,119,255,0.2)] p-3 outline-none resize-y bg-white relative z-10 rounded-md transition-all duration-200" 
              rows={3}
              defaultValue="同意"
            />
          </section>

          {/* Action Buttons - Ant Design styling */}
          <div className="flex justify-center items-center space-x-3 mt-8 pb-4 relative z-10">
            {/* Primary Button */}
            <button className="bg-[#1677ff] hover:bg-[#4096ff] text-white px-6 py-1.5 h-8 rounded-md shadow-sm border border-transparent transition-all duration-200 text-sm cursor-pointer flex items-center justify-center">
              同意
            </button>
            {/* Default Buttons */}
            <button className="bg-white hover:text-[#1677ff] hover:border-[#1677ff] text-[rgba(0,0,0,0.88)] px-6 py-1.5 h-8 rounded-md shadow-sm border border-[#d9d9d9] transition-all duration-200 text-sm cursor-pointer flex items-center justify-center">
              驳回
            </button>
            <button className="bg-white hover:text-[#1677ff] hover:border-[#1677ff] text-[rgba(0,0,0,0.88)] px-6 py-1.5 h-8 rounded-md shadow-sm border border-[#d9d9d9] transition-all duration-200 text-sm cursor-pointer flex items-center justify-center">
              返回
            </button>
            <button className="bg-white hover:text-[#1677ff] hover:border-[#1677ff] text-[rgba(0,0,0,0.88)] px-6 py-1.5 h-8 rounded-md shadow-sm border border-[#d9d9d9] transition-all duration-200 text-sm cursor-pointer flex items-center justify-center">
              加签
            </button>
          </div>

        </div>
      </div>

    </div>
  );
};

export default ApplicationForm;